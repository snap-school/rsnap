(function() {
  jQuery(function() {
    return $('#sortable').sortable({
      axis: 'y',
      items: '.item',
      stop: function(e, ui) {
        return ui.item.children('td').effect('highlight', {}, 1000);
      },
      update: function(e, ui) {
        var data_transfered, position;
        position = ui.item.index();
        data_transfered = {
          data: {
            thing: {}
          }
        };
        data_transfered['data']['thing'][ui.item.data('ordered-row') + '_position'] = position;
        return $.ajax({
          type: 'PUT',
          url: ui.item.data('update-url'),
          dataType: 'json',
          data: data_transfered['data']
        });
      }
    });
  });

}).call(this);
