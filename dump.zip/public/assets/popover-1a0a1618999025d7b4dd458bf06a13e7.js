(function() {
  $(function() {
    return $('.popover-default').popover({
      html: true
    });
  });

  $(function() {
    return $('body').on('click', function(e) {
      return $('.popover-default').each(function() {
        if (!$(this).is(e.target) && $(this).has(e.target).length === 0 && $('.popover').has(e.target).length === 0) {
          return $(this).popover('hide');
        }
      });
    });
  });

}).call(this);
