(function() {
  var addLoadEvent, getAsset, getURL;

  addLoadEvent = function(func) {
    var oldonload;
    oldonload = window.onload;
    if (typeof window.onload !== "function") {
      window.onload = func;
    } else {
      window.onload = function() {
        if (oldonload) {
          oldonload();
        }
        func();
      };
    }
  };

  window.addLoadEvent = addLoadEvent;

  getURL = function(url, async) {
    var err, request;
    if (async == null) {
      async = false;
    }
    try {
      request = new XMLHttpRequest();
      request.open("GET", url, async);
      request.send();
      if (request.status === 200) {
        return request.responseText;
      }
      throw new Error("unable to retrieve " + url);
    } catch (_error) {
      err = _error;
      return err;
    }
  };

  window.getURL = getURL;

  getAsset = function(name) {
    if (typeof window.assetsUrl === 'undefined') {
      window.assetsUrl = JSON.parse(getURL("/snap_assets.json"));
    }
    return window.assetsUrl[name];
  };

  window.getAsset = getAsset;

}).call(this);
